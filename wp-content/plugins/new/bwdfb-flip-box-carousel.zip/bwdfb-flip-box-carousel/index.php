<?php
/**
 * Silence is golden
 */