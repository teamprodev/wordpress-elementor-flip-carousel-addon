

<div class="bwdfb-for-all-owlCarousel"
    bwdfb-data-margin="<?php echo esc_attr( $bwdfb_slide_margin );?>"
    bwdfb-data-desktop="<?php echo esc_attr( $bwdfb_slide_desktop_view );?>"
    bwdfb-data-tablet="<?php echo esc_attr( $bwdfb_slide_tablet_view );?>"
    bwdfb-data-mobile="<?php echo esc_attr( $bwdfb_slide_mobile_view );?>"

    bwdfb-data-autoplay="<?php echo esc_attr( $bwdfb_infinite_autoplay_switcher );?>"
    bwdfb-data-loop="<?php echo esc_attr( $bwdfb_infinite_loop_switcher );?>"
    bwdfb-data-hoverpause="<?php echo esc_attr( $bwdfb_HoverPause_switcher );?>"
    bwdfb-data-centermode="<?php echo esc_attr( $bwdfb_centermode_switcher );?>"
    bwdfb-data-timeout="<?php echo esc_attr( $bwdfb_autoplay_timeout );?>"
    bwdfb-data-autospeed="<?php echo esc_attr( $bwdfb_autoplay_speed );?>"
    bwdfb-data-stagepadding ="<?php echo esc_attr( $bwdfb_stace_padding );?>"

    bwdfb-data-navigations="<?php echo esc_attr( $bwdfb_nav_switcher );?>"
    bwdfb-data-navtype="<?php echo esc_attr( $bwdfb_nav_type );?>"
    bwdfb-data-navprev="<?php echo esc_attr( $prev );?>"
    bwdfb-data-navnext="<?php echo esc_attr( $next );?>"

    bwdfb-data-dots="<?php echo esc_attr( $bwdfb_dots_switcher );?>"
    bwdfb-data-dotstype="<?php echo esc_attr( $bwdfb_dots_type );?>"></div>